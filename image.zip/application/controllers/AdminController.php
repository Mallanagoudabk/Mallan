<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AdminController extends CI_Controller{
     public function __construct() {
        parent::__construct();
     $this->load->Model('AdminModel');  
    }
  
    function index(){
        //default 
        $this->load->view('home');
    }
     function User(){
         //load the view product.php 
    $this->load->view('user');
}

}

?>
