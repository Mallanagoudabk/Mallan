<?php
error_reporting(1);
session_start();

$this->load->view('header');
?>
<div class="content-wrapper">

    <section class="content">

        <!-- Default box -->
        <div class="box">
            <div class="box-header with-border">
                <h4 class=""> <i class="fa fa-users"> </i> ALL CATEGORY</h4>

                <div class="box-tools pull-right" style="padding:10px;">

                    <button type="button" class="btn btn-flat bg-black-gradient" onclick="showAjaxModal('ADD CATEGORY', 'AdminController/Modal', 'add_category', '0')">
                        <b style="font-size: 16px;"> ADD </b>
                    </button>

                </div>
            </div>
            <div class="box-body">
                <div class="row"><br>
                    <div class="col-sm-12 table-responsive">
                        <table class="table table-responsive table-bordered table-condensed" id="category">
                            <thead class="bg-black-gradient">
                                <tr>
                                    <th style="text-align: center;">#</th>
                                    <th style="text-align: center;">Category name </th>
                                    <th style="text-align: center;">Priority </th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                $query = $this->db->select('*')->from('categories')->get();

                                if ($query->num_rows() > 0) {
                                    foreach ($query->result_array() as $row) {
                                        ?>
                                        <tr>
                                            <td style="text-align: center;"><?php echo $i; ?></td>
                                            <td><?php echo $row['name']; ?></td>
                                            <td style="text-align: center;"><?php echo $row['priority']; ?></td>
                                            <td style="text-align: center;">
                                                <a><i class="btn btn-info fa fa-edit" onclick="showAjaxModal('EDIT CATEGORY', 'AdminController/Modal', 'add_category', '<?php echo $row['id']; ?>')"></i></a>
                                                <a onclick="delete_it('<?php echo base_url(); ?>AdminController/Deletecat/<?php echo $row['id']; ?>')"><i class="btn btn-danger fa fa-trash"></i></a>
                                            </td>
                                        </tr>
        <?php
        $i++;
    }
}
?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- /.box-footer-->
        </div>
    </section>
    <!-- /.content -->
</div>
<?php
$this->load->view('admin/footer')
?>
<script>
    $(document).ready(function () {
        $('#category').DataTable();
    });
</script>