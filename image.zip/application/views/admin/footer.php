<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2018 <a href="https://adminlte.io">Company</a>.</strong> All rights
    reserved.
  </footer>

<script src="<?php echo base_url();?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url();?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url();?>bower_components/select2/dist/js/select2.full.min.js"></script>
<script src="<?php echo base_url();?>bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url();?>bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url();?>bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo base_url();?>bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo base_url();?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo base_url();?>dist/js/adminlte.min.js"></script>
<!--<script src="../dist/js/datatables.js"></script>
<script src="../dist/js/all_functions.js"></script>-->
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>dist/js/demo.js"></script>
<script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
 $(document).ready(function () {
    $('.sidebar-menu').tree();
      $('.select2').select2();
      $('#datepicker').datepicker({
      autoclose: true
    });
    });
  function showAjaxModal(title,path,type,id)
   {
       
       $('#myModal').modal('show');
       $('#myModal .modal-title').html(title);
       $.ajax({
           type : 'post',
           url : base+''+path,
           data : {
               type : type,
               id  : id
           },
            success: function(data)
           {
                $('#myModal .body').html(data);
           },
       });
   }
   
   function delete_it(url)
   {
       if(confirm("Do you really want to delete it ...... ?"))
       {
        window.location=url;   
       }
   }
   
</script>
</body>
</html>
