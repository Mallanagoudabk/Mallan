<?php
$this->load->view('header');
// $contents = file_get_contents("https://jsonplaceholder.typicode.com/users");
// $data = json_encode($contents, true);
// # preg_match('/^.+[\n](.+)[\n]./', $contents, $matches);
// echo $data[21];
//the json is in $matches[1]
// print_r($matches);

 $query=$this->db->select('*')->from('user')->get();

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       HOME
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
        <div class="row">
          <?php
          foreach ($query->result_array() as $row) {
            ?>
          <a href='<?php echo base_url();?>AdminController/user?id=<?php echo $row['id']; ?>' >
         
        <div class="col-md-3 col-sm-6 col-xs-12" >
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-cart-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text" ><?php echo $row['name']; ?> </span>
           
              <!-- <ul id="authors"></ul> -->
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        </a> 
        <?php

      }
      ?>
            
      
        <div class="clearfix visible-sm-block"></div>

      </div>
     

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script type="text/javascript">

    function createNode(element) {
      return document.createElement(element);
  }

  function append(parent, el) {
    return parent.appendChild(el);
  }

  const ul = document.getElementById('authors');
  const url = 'https://jsonplaceholder.typicode.com/users';
  fetch(url)
  .then((resp) => resp.json())
  .then(function(data) {
    let authors = data;
    return authors.map(function(author) {
      let li = createNode('span'),
          span = createNode('span');
      span.innerHTML = `${author.id} ${author.name}`;
      // append(li, span);
      append(ul, span); 
    })
  })
  .catch(function(error) {
    console.log(JSON.stringify(error));
  });   

</script>
<?php
$this->load->view('admin/footer.php');
?>
  