<?php
$this->load->view('header');
$id = $_GET['id'];

$query=$this->db->select('*')->from('user')->where('id',$id)->get();
foreach ($query->result_array() as $row);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       HOME
      </h1>
      <ol class="breadcrumb">
        <!-- <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li> -->
      </ol>
    </section>
    
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <a href="<?php echo base_url();?>AdminController/user">
        <div class="col-md-6 col-sm-6 col-xs-12" >
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-cart-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text" id=""> </span>
           
              <ul >Name: <?php echo $row['name']; ?></ul>
              <ul >Name: <?php echo $row['mobile']; ?></ul>
              <ul >Name: <?php echo $row['company']; ?></ul>
              <ul >Name: <?php echo $row['address']; ?></ul>
              <ul >Name: <?php echo $row['city']; ?></ul>
              <ul >Name: <?php echo $row['website']; ?></ul>
              <ul >Name: <?php echo $row['zipcode']; ?></ul>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
            </a>
      
        <div class="clearfix visible-sm-block"></div>

      </div>
     

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script type="text/javascript">

    function createNode(element) {
      return document.createElement(element);
  }

  function append(parent, el) {
    return parent.appendChild(el);
  }

  const ul = document.getElementById('authors');
  const url = 'https://jsonplaceholder.typicode.com/users';
  fetch(url)
  .then((resp) => resp.json())
  .then(function(data) {
    let authors = data;
    return authors.map(function(author) {
      let li = createNode('span'),
          span = createNode('span');
      span.innerHTML = `${author.id} ${author.name} ${author.email} `;
      append(li, span);
      append(ul, span); 
    })
  })
  .catch(function(error) {
    console.log(JSON.stringify(error));
  });   

</script>
<?php
$this->load->view('admin/footer.php');
?>
  